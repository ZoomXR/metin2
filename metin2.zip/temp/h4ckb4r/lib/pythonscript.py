import dbg
dbg.LogBox("edit pythonscript.py")

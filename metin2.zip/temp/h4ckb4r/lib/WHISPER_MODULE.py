## with this file you can create whisper bot, log whisper messages, detect if wite gm or player
## sample scripts included, uncomment them if wan't use
import app
import thread
import playerm2g2 as player
import chatm2g as chat

try:
	import m2netm2g as m2net
except:
	import net as m2net

try:
	import cleverbot
except:
	pass

CLEVERBOT_ENABLED = 0

def RUN(self, mode, name, text):
	## SAMPLE SCRIPTs: 
	## LOG MESSAGES to a text file:
	#w = open("whisper_log.txt", "a")
	#w.write("%s : %s\n" % (name, text))
	#w.close()
	
	## EXIT GAME IF GM WRITE:
	#if mode==5:
	#	app.Abort()
	
	## RESPOND message:
	#if "Hello" in text: # player message
	#	def msg():
	#		app.Sleep(3000) # wait 3 seconds
	#		m2net.SendWhisperPacket(name, "hi") # send message
	#		
	#	thread.start_new_thread(msg, ()) # create new thread for sleep, so game will not freeze.
	
	##CleverBot (people who write to you will receive message from cleverbot):
	if CLEVERBOT_ENABLED == 1:
		def msg():
			app.Sleep(2000)
			cb1 = cleverbot.Cleverbot()
			answer = cb1.ask(text)
			m2net.SendWhisperPacket(name, answer)
			#chat.AppendWhisper(chat.WHISPER_TYPE_CHAT, name, player.GetName() + " : " + answer)
		thread.start_new_thread(msg, ())

	return 0 #return 1 will not recieve any messages
